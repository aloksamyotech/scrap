import axios from "axios";
import { findOtp } from "./otp.js";

export const findOtpNumber = async () => {
    let runner = true
    let val = null
    while (runner) {
        await new Promise(resolve => setTimeout(resolve, 2000));
        let otp = await findOtp()
        console.log("otp", otp.otp)
        if (otp.otp !== 0) {
            val = otp.otp
            runner = false
        }
    }
    if (!runner) {
        return val
    }

}


export function generateNewURL(searchQuery) {
    const baseURL = "https://www.instacart.com/store/razco-foods-supermarket/s?k=Electrolit+Cucumber+Lime"
    const encodedQuery = encodeURIComponent(searchQuery).replace(/%20/g, '+');
    return baseURL.replace(/(\?k=)[^&]+/, `$1${encodedQuery}`);
}


export async function getRawData() {
    try {
        const rawdata = await axios.get('http://147.182.229.247:3015/api/v1/row-product/get-all/pagination/2/2')
        console.log("rawdata=========>>>>>", rawdata?.data?.data)
        return rawdata?.data?.data
    } catch (error) {
        console.log("error==========>>>>>>>", error)
    }
}


export async function postProductData(payload) {
    try {
        const response = await axios.post('http://147.182.229.247/api/v1/product/upload/with-scraping', payload)
        console.log("respnse78888888============>>>>",response)
        return response
    } catch (error) {
        console.log("error=======>>>>>>>>", error)
    }
}
