import puppeteer from "puppeteer";
import { findOtpNumber, generateNewURL, getRawData, postProductData } from "../helper/helper.js";
import { Auth } from "../helper/model.js";
import { extractImageUrls } from "../helper/test.js";
import { response } from "express";
export async function scrapeInstacart(searchURL) {
    console.log(`🚀 Launching Puppeteer to scrape: ${searchURL}`);

    const browser = await puppeteer.launch({
        headless: false,
    });

    try {
        const page = await browser.newPage();
        await page.setViewport({ width: 1280, height: 800 });
        while (true) {
            const values = await getRawData()
            console.log("values========>>>>>>>>>>>>>>>>", values)
            let results = []
   
            for (const searchItem of values) {
                let screpUrl = generateNewURL(searchItem?.item_name_extended);
                console.log(`🌍 Navigating to: ${screpUrl}`);
                await page.goto(screpUrl);
                await new Promise(resolve => setTimeout(resolve, 10000));
                console.log(`🔍 Looking for product images inside div.e-ec1gba for "${searchItem}"`);
                const productDivs = await page.evaluate(() => {
                    let productContainers = document.querySelectorAll('div.e-ec1gba');
                    return Array.from(productContainers).map(div => div.outerHTML);
                });
                const imageUrls = extractImageUrls(productDivs)
                results.push({
                    _id: searchItem?._id,
                    image_urls: imageUrls.slice(0, 2),
                    isralavent: false
                })
                console.log("results========>>>", results)
            }
            const respnse = await postProductData(results)
            console.log("response==========>>>>", respnse)
        }
    } catch (error) {
        console.error("❌ Error during scraping:", error);
    } finally {
        console.log("🔴 Closing Puppeteer...");
        await Auth.updateOne({ otp: 0 })
        await browser.close();
    }
}
